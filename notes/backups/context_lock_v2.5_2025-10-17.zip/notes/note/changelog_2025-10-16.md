# Changelog

## 2025-10-15
### [init] Project structure created
- initialized frontend and backend environments
- created .env.example, .gitignore, LICENSE
- verified directory structure
