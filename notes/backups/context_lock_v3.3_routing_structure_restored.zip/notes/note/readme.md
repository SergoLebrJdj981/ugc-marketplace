# Notes System Overview

Этот каталог содержит всю внутреннюю документацию проекта **UGC Marketplace**. Файлы поддерживаются в синхронизированном состоянии: план, задачи, журнал изменений и руководство по интерфейсу.

## Основные документы
- `project_plan.md` — архитектура, дорожная карта и стратегический контекст.
- `tasks.md` — иерархический список модулей и задач с фиксацией статусов.
- `changelog.md` — история изменений и контрольные точки версии.
- `ui_guide.md` — визуальные и UX-гайдлайны интерфейса.

## Регламент обновления
1. Все изменения в кодовой базе сопровождаются обновлением `tasks.md` и `changelog.md`.
2. После каждого завершённого подмодуля оформляется запись в `changelog.md` и выполняется commit.
3. Перед ревизией GPT необходимо убедиться, что backups в `notes/backups` актуальны.

## Автосохранение и резервное копирование
- VS Code настроен на автоматическое сохранение файлов в каталоге `notes`.
- При обновлении ключевых документов создаётся резервная копия в `notes/backups` с префиксом текущей даты (`YYYY-MM-DD_`).

## Ответственные роли
- **GPT** — поддерживает архитектуру и консистентность документации.
- **Codex** — реализует технические задачи и ведёт историю изменений.
- **Серджиу** — подтверждает результаты и фиксирует ключевые версии (Context Lock).

Документация всегда редактируется строго по регламенту, чтобы обеспечить прозрачность и прослеживаемость изменений.

## Git Workflow
- Ветки: `main` — release, `dev` — development, `feature/*` — новые фичи.
- Рабочий цикл:
  1. Создай ветку от `dev`: `git checkout -b feature/<название>`.
  2. Выполни изменения → commit → push.
  3. Открой Pull Request → `dev` → `main`.
- Каждый commit проходит автоматическую проверку (husky + lint-staged).

## Database Structure (Context Lock v2.1)
- ORM реализована на SQLAlchemy 2.0 + Alembic.
- Основные таблицы:
  - `users`: список всех ролей, уникальный email, статусы активности.
  - `campaigns`: кампании брендов, связь `brand_id -> users.id`, бюджет с ограничением `budget >= 0`.
  - `applications`: отклики креаторов, уникальность `campaign_id + creator_id`, статусы в `application_status`.
  - `orders`: утверждённые сделки, связь с `applications`, хранит `creator_id` и `brand_id`.
  - `videos` / `payments`: материалы и финансовые операции по заказу.
  - `ratings`: качественные оценки пользователей с уникальным `source`.
  - `reports`: аналитические и операционные отчёты (agent/factory).
- Все перечисления (`user_role`, `campaign_status`, `order_status` и др.) зафиксированы в БД; дамп схемы доступен в `backend/app/schema_dump.sql`.

## API Usage Guide
- Запуск dev-сервера: `uvicorn app.main:app --reload --app-dir backend/app`.
- Swagger-документация: `http://localhost:8000/docs`.
- Примеры запросов:
  - Регистрация: `POST /api/auth/register` с телом `{"email": "...", "password": "Secret123!", "role": "brand"}`.
  - Создание кампании: `POST /api/campaigns` (Bearer токен бренда, `brand_id` заполняется автоматически).
  - Заморозка средств: `POST /api/payments` с `{"order_id": "<uuid>", "payment_type": "hold", "amount": "45000.00", "currency": "RUB"}`.
  - Профиль бренда: `POST /api/brands` (Bearer токен бренда, параметры `name`, `description`).

## Notifications & Webhooks
- `/api/notifications` — получение уведомлений и фильтрация по `user_id`.
- `/api/notifications/mark-read` — отметить список уведомлений как прочитанные.
- `/api/webhooks/payment` — пример webhook-запроса платёжной системы (`{"payment_id": "...", "status": "completed"}`).
- `/api/webhooks/order` — обновление статуса заказа (`{"order_id": "...", "status": "delivered"}`).

## Security & Middleware
- JWT: access (15 мин) + refresh (7 дней), алгоритм HS256, обновление через `/api/auth/refresh`, logout ревокирует refresh.
- CORS: разрешённые origin'ы берутся из `ALLOWED_ORIGINS` (по умолчанию `http://localhost:3000`).
- Rate limiter: 60 запросов/минуту на IP, превышение → HTTP 429.
- Централизованная обработка ошибок: единый JSON-формат ответа с полями `status`, `code`, `message`, `details`.
- Логи: Loguru пишет запросы и ошибки в `logs/app.log`.

## Admin API
- `/api/admin/users` — управление пользователями, изменение ролей, удаление.
- `/api/admin/campaigns` — обзор кампаний, заморозка, удаление (для superuser).
- `/api/admin/statistics` — агрегированные метрики + `/export` для CSV.
- Роли:
  - `admin_level_1` — Moderator (просмотр, блокировка).
  - `admin_level_2` — Finance (статистика и финансы).
  - `admin_level_3` — Superuser (полный доступ, изменение ролей, удаление).
